import java.awt.*;
import javax.swing.*;
public class Lab10 {
    private JFrame popo;
    private JPanel num;
    private JTextField tf;
    private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0 ,bp,bm,bx,bd,bc,be;
    public Lab10() {
        popo = new JFrame("popo");
        num = new JPanel();
        b1 = new JButton("1");
        b2 = new JButton("2");
        b3 = new JButton("3");
        b4 = new JButton("4");
        b5 = new JButton("5");
        b6 = new JButton("6");
        b7 = new JButton("7");
        b8 = new JButton("8");
        b9 = new JButton("9");
        b0 = new JButton("0");
        bp = new JButton("+");
        bm = new JButton("-");
        bx = new JButton("x");
        bd = new JButton("/");
        bc = new JButton("c");
        be = new JButton("=");
        popo = new JFrame("Button Sample");
        tf = new JTextField(20); 
        popo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        num.setLayout(new GridLayout(4,4));
        num.add(b7);num.add(b8);num.add(b9);num.add(bp);
        num.add(b4);num.add(b5);num.add(b6);num.add(bm);
        num.add(b1);num.add(b2);num.add(b3);num.add(bx);
        num.add(b0);num.add(bc);num.add(be);num.add(bd);
        popo.add(tf, BorderLayout.NORTH);
        popo.add(num, BorderLayout.CENTER);
        popo.setSize(300, 300);
        popo.setVisible(true);

    }
    
}
